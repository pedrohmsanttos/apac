<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Licitacoes
 * @author     Pedro Santos <phmsanttos@gmail.com>
 * @copyright  2018 Pedro Santos
 * @license    GNU General Public License versão 2 ou posterior; consulte o arquivo License. txt
 */

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.controllerform');

/**
 * Licitacao controller class.
 *
 * @since  1.6
 */
class LicitacoesControllerArquivo extends JControllerForm
{



	/**
	 * Constructor
	 *
	 * @throws Exception
	 */
	public function __construct()
	{
		$this->view_list = 'arquivo';
		parent::__construct();
	}

	public function save(){
		var_dump($this->input->post->get('jform', array(), 'array'));die;
		die("teste parou");
	}
}
