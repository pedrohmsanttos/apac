DROP TABLE IF EXISTS "#__licitacoes";
DROP TABLE IF EXISTS "#__modalidade_licitacao";

