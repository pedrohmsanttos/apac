DROP TABLE IF EXISTS `#__licitacoes`;
